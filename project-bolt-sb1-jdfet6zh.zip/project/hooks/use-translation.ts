'use client';

import { useLanguageContext } from '@/components/language-provider';

// Translation data
const translations = {
  en: {
    // Navigation
    customize: 'Customize',
    gallery: 'Gallery',
    howItWorks: 'How It Works',
    cart: 'Cart',
    loginWithSpotify: 'Login with Spotify',
    
    // User account
    myAccount: 'My Account',
    profile: 'Profile',
    savedDesigns: 'Saved Designs',
    orderHistory: 'Order History',
    settings: 'Settings',
    logout: 'Logout',
    
    // Homepage
    hero: {
      title: 'Wear Your Music',
      subtitle: 'Turn your favorite Spotify tracks into stylish wristbands',
      cta: 'Start Designing',
      secondaryCta: 'See Examples'
    },
    features: {
      title: 'Why Wristify?',
      feature1Title: 'Spotify Integration',
      feature1Desc: 'Connect with Spotify to select from your favorite songs',
      feature2Title: 'Scannable Codes',
      feature2Desc: 'Wristbands include scannable Spotify codes to play your song instantly',
      feature3Title: '3D Preview',
      feature3Desc: 'See exactly how your wristband will look before ordering',
      feature4Title: 'Quality Materials',
      feature4Desc: 'Durable, comfortable materials built to last'
    },
    
    // Customizer
    customizer: {
      title: 'Design Your Wristband',
      songInput: 'Enter Spotify Song URL',
      or: 'or',
      searchSongs: 'Search for a song',
      songPlaceholder: 'Song name or artist...',
      selectedSong: 'Selected Song',
      printStyle: 'Print Style',
      spotifyCode: 'Spotify Code',
      textOnly: 'Text Only',
      preview: 'Preview',
      addToCart: 'Add to Cart',
      saveDesign: 'Save Design'
    },
    
    // Materials
    materials: {
      title: 'Material',
      silicone: 'Silicone',
      outOfStock: 'Out of Stock'
    },
    
    // Colors
    colors: {
      title: 'Color',
      black: 'Black',
      white: 'White'
    },
    
    // Checkout
    checkout: {
      title: 'Checkout',
      shippingInfo: 'Shipping Information',
      fullName: 'Full Name',
      address: 'Address',
      city: 'City',
      state: 'State/Province',
      zip: 'ZIP/Postal Code',
      country: 'Country',
      phone: 'Phone Number',
      email: 'Email Address',
      orderSummary: 'Order Summary',
      subtotal: 'Subtotal',
      shipping: 'Shipping',
      tax: 'Tax',
      total: 'Total',
      paymentMethods: 'Payment Methods',
      placeOrder: 'Place Order'
    },
    
    // Footer
    footerTagline: 'Wear your favorite music everywhere you go',
    products: 'Products',
    customizeWristband: 'Customize Wristband',
    designGallery: 'Design Gallery',
    giftCards: 'Gift Cards',
    company: 'Company',
    aboutUs: 'About Us',
    faq: 'FAQ',
    contactUs: 'Contact Us',
    legal: 'Legal',
    termsOfService: 'Terms of Service',
    privacyPolicy: 'Privacy Policy',
    shippingPolicy: 'Shipping Policy',
    refundPolicy: 'Refund Policy',
    allRightsReserved: 'All Rights Reserved',
    
    // Language names (for language selector)
    english: 'English',
    turkish: 'Turkish',
    arabic: 'Arabic',
    spanish: 'Spanish'
  },
  tr: {
    // Navigation
    customize: 'Özelleştir',
    gallery: 'Galeri',
    howItWorks: 'Nasıl Çalışır',
    cart: 'Sepet',
    loginWithSpotify: 'Spotify ile Giriş Yap',
    
    // User account
    myAccount: 'Hesabım',
    profile: 'Profil',
    savedDesigns: 'Kaydedilen Tasarımlar',
    orderHistory: 'Sipariş Geçmişi',
    settings: 'Ayarlar',
    logout: 'Çıkış Yap',
    
    // Homepage
    hero: {
      title: 'Müziğini Takın',
      subtitle: 'En sevdiğiniz Spotify parçalarını şık bilekliklere dönüştürün',
      cta: 'Tasarlamaya Başla',
      secondaryCta: 'Örnekleri Gör'
    },
    features: {
      title: 'Neden Wristify?',
      feature1Title: 'Spotify Entegrasyonu',
      feature1Desc: 'Favori şarkılarınızı seçmek için Spotify\'a bağlanın',
      feature2Title: 'Taranabilir Kodlar',
      feature2Desc: 'Bileklikler, şarkınızı anında çalmak için taranabilir Spotify kodları içerir',
      feature3Title: '3D Önizleme',
      feature3Desc: 'Sipariş vermeden önce bileğinizin tam olarak nasıl görüneceğini görün',
      feature4Title: 'Kaliteli Malzemeler',
      feature4Desc: 'Dayanıklı, rahat, uzun ömürlü malzemeler'
    },
    
    // Customizer
    customizer: {
      title: 'Bileğinizi Tasarlayın',
      songInput: 'Spotify Şarkı URL\'si Girin',
      or: 'veya',
      searchSongs: 'Bir şarkı arayın',
      songPlaceholder: 'Şarkı adı veya sanatçı...',
      selectedSong: 'Seçilen Şarkı',
      printStyle: 'Baskı Stili',
      spotifyCode: 'Spotify Kodu',
      textOnly: 'Sadece Metin',
      preview: 'Önizleme',
      addToCart: 'Sepete Ekle',
      saveDesign: 'Tasarımı Kaydet'
    },
    
    // Materials
    materials: {
      title: 'Materyal',
      silicone: 'Silikon',
      outOfStock: 'Stokta Yok'
    },
    
    // Colors
    colors: {
      title: 'Renk',
      black: 'Siyah',
      white: 'Beyaz'
    },
    
    // Checkout
    checkout: {
      title: 'Ödeme',
      shippingInfo: 'Kargo Bilgileri',
      fullName: 'Ad Soyad',
      address: 'Adres',
      city: 'Şehir',
      state: 'İlçe/Eyalet',
      zip: 'Posta Kodu',
      country: 'Ülke',
      phone: 'Telefon Numarası',
      email: 'E-posta Adresi',
      orderSummary: 'Sipariş Özeti',
      subtotal: 'Ara Toplam',
      shipping: 'Kargo',
      tax: 'Vergi',
      total: 'Toplam',
      paymentMethods: 'Ödeme Yöntemleri',
      placeOrder: 'Sipariş Ver'
    },
    
    // Footer
    footerTagline: 'En sevdiğiniz müziği her yere takın',
    products: 'Ürünler',
    customizeWristband: 'Bileklik Özelleştir',
    designGallery: 'Tasarım Galerisi',
    giftCards: 'Hediye Kartları',
    company: 'Şirket',
    aboutUs: 'Hakkımızda',
    faq: 'SSS',
    contactUs: 'İletişim',
    legal: 'Yasal',
    termsOfService: 'Kullanım Koşulları',
    privacyPolicy: 'Gizlilik Politikası',
    shippingPolicy: 'Kargo Politikası',
    refundPolicy: 'İade Politikası',
    allRightsReserved: 'Tüm Hakları Saklıdır',
    
    // Language names (for language selector)
    english: 'İngilizce',
    turkish: 'Türkçe',
    arabic: 'Arapça',
    spanish: 'İspanyolca'
  },
  ar: {
    // Navigation
    customize: 'تخصيص',
    gallery: 'معرض',
    howItWorks: 'كيف يعمل',
    cart: 'سلة التسوق',
    loginWithSpotify: 'تسجيل الدخول مع سبوتيفاي',
    
    // User account
    myAccount: 'حسابي',
    profile: 'الملف الشخصي',
    savedDesigns: 'التصاميم المحفوظة',
    orderHistory: 'سجل الطلبات',
    settings: 'الإعدادات',
    logout: 'تسجيل الخروج',
    
    // Homepage
    hero: {
      title: 'ارتدي موسيقاك',
      subtitle: 'حول مساراتك المفضلة من سبوتيفاي إلى أساور أنيقة',
      cta: 'ابدأ التصميم',
      secondaryCta: 'شاهد الأمثلة'
    },
    features: {
      title: 'لماذا ويستيفاي؟',
      feature1Title: 'تكامل سبوتيفاي',
      feature1Desc: 'اتصل بسبوتيفاي للاختيار من أغانيك المفضلة',
      feature2Title: 'رموز قابلة للمسح',
      feature2Desc: 'تتضمن الأساور رموز سبوتيفاي قابلة للمسح لتشغيل أغنيتك فوراً',
      feature3Title: 'عرض ثلاثي الأبعاد',
      feature3Desc: 'شاهد بالضبط كيف ستبدو أساورك قبل الطلب',
      feature4Title: 'مواد عالية الجودة',
      feature4Desc: 'مواد متينة ومريحة مصممة لتدوم'
    },
    
    // Customizer
    customizer: {
      title: 'صمم أساورك',
      songInput: 'أدخل رابط أغنية سبوتيفاي',
      or: 'أو',
      searchSongs: 'ابحث عن أغنية',
      songPlaceholder: 'اسم الأغنية أو الفنان...',
      selectedSong: 'الأغنية المختارة',
      printStyle: 'نمط الطباعة',
      spotifyCode: 'رمز سبوتيفاي',
      textOnly: 'نص فقط',
      preview: 'معاينة',
      addToCart: 'أضف إلى السلة',
      saveDesign: 'حفظ التصميم'
    },
    
    // Materials
    materials: {
      title: 'المادة',
      silicone: 'سيليكون',
      outOfStock: 'غير متوفر'
    },
    
    // Colors
    colors: {
      title: 'اللون',
      black: 'أسود',
      white: 'أبيض'
    },
    
    // Checkout
    checkout: {
      title: 'الدفع',
      shippingInfo: 'معلومات الشحن',
      fullName: 'الاسم الكامل',
      address: 'العنوان',
      city: 'المدينة',
      state: 'المنطقة/المقاطعة',
      zip: 'الرمز البريدي',
      country: 'الدولة',
      phone: 'رقم الهاتف',
      email: 'البريد الإلكتروني',
      orderSummary: 'ملخص الطلب',
      subtotal: 'المجموع الفرعي',
      shipping: 'الشحن',
      tax: 'الضريبة',
      total: 'المجموع الكلي',
      paymentMethods: 'طرق الدفع',
      placeOrder: 'تقديم الطلب'
    },
    
    // Footer
    footerTagline: 'ارتدِ موسيقاك المفضلة أينما ذهبت',
    products: 'المنتجات',
    customizeWristband: 'تخصيص الأساور',
    designGallery: 'معرض التصاميم',
    giftCards: 'بطاقات الهدايا',
    company: 'الشركة',
    aboutUs: 'من نحن',
    faq: 'الأسئلة الشائعة',
    contactUs: 'اتصل بنا',
    legal: 'قانوني',
    termsOfService: 'شروط الخدمة',
    privacyPolicy: 'سياسة الخصوصية',
    shippingPolicy: 'سياسة الشحن',
    refundPolicy: 'سياسة الاسترداد',
    allRightsReserved: 'جميع الحقوق محفوظة',
    
    // Language names (for language selector)
    english: 'الإنجليزية',
    turkish: 'التركية',
    arabic: 'العربية',
    spanish: 'الإسبانية'
  },
  es: {
    // Navigation
    customize: 'Personalizar',
    gallery: 'Galería',
    howItWorks: 'Cómo Funciona',
    cart: 'Carrito',
    loginWithSpotify: 'Iniciar con Spotify',
    
    // User account
    myAccount: 'Mi Cuenta',
    profile: 'Perfil',
    savedDesigns: 'Diseños Guardados',
    orderHistory: 'Historial de Pedidos',
    settings: 'Configuración',
    logout: 'Cerrar Sesión',
    
    // Homepage
    hero: {
      title: 'Lleva tu Música',
      subtitle: 'Convierte tus canciones favoritas de Spotify en elegantes pulseras',
      cta: 'Empezar a Diseñar',
      secondaryCta: 'Ver Ejemplos'
    },
    features: {
      title: '¿Por qué Wristify?',
      feature1Title: 'Integración con Spotify',
      feature1Desc: 'Conecta con Spotify para seleccionar tus canciones favoritas',
      feature2Title: 'Códigos Escaneables',
      feature2Desc: 'Las pulseras incluyen códigos de Spotify escaneables para reproducir tu canción al instante',
      feature3Title: 'Vista previa en 3D',
      feature3Desc: 'Ve exactamente cómo se verá tu pulsera antes de ordenar',
      feature4Title: 'Materiales de Calidad',
      feature4Desc: 'Materiales duraderos y cómodos construidos para durar'
    },
    
    // Customizer
    customizer: {
      title: 'Diseña tu Pulsera',
      songInput: 'Introduce URL de canción de Spotify',
      or: 'o',
      searchSongs: 'Busca una canción',
      songPlaceholder: 'Nombre de canción o artista...',
      selectedSong: 'Canción Seleccionada',
      printStyle: 'Estilo de Impresión',
      spotifyCode: 'Código de Spotify',
      textOnly: 'Solo Texto',
      preview: 'Vista Previa',
      addToCart: 'Añadir al Carrito',
      saveDesign: 'Guardar Diseño'
    },
    
    // Materials
    materials: {
      title: 'Material',
      silicone: 'Silicona',
      outOfStock: 'Agotado'
    },
    
    // Colors
    colors: {
      title: 'Color',
      black: 'Negro',
      white: 'Blanco'
    },
    
    // Checkout
    checkout: {
      title: 'Pago',
      shippingInfo: 'Información de Envío',
      fullName: 'Nombre Completo',
      address: 'Dirección',
      city: 'Ciudad',
      state: 'Estado/Provincia',
      zip: 'Código Postal',
      country: 'País',
      phone: 'Número de Teléfono',
      email: 'Correo Electrónico',
      orderSummary: 'Resumen del Pedido',
      subtotal: 'Subtotal',
      shipping: 'Envío',
      tax: 'Impuestos',
      total: 'Total',
      paymentMethods: 'Métodos de Pago',
      placeOrder: 'Realizar Pedido'
    },
    
    // Footer
    footerTagline: 'Lleva tu música favorita a donde quiera que vayas',
    products: 'Productos',
    customizeWristband: 'Personalizar Pulsera',
    designGallery: 'Galería de Diseños',
    giftCards: 'Tarjetas de Regalo',
    company: 'Empresa',
    aboutUs: 'Sobre Nosotros',
    faq: 'Preguntas Frecuentes',
    contactUs: 'Contacto',
    legal: 'Legal',
    termsOfService: 'Términos de Servicio',
    privacyPolicy: 'Política de Privacidad',
    shippingPolicy: 'Política de Envío',
    refundPolicy: 'Política de Reembolso',
    allRightsReserved: 'Todos los Derechos Reservados',
    
    // Language names (for language selector)
    english: 'Inglés',
    turkish: 'Turco',
    arabic: 'Árabe',
    spanish: 'Español'
  }
};

export const useTranslation = () => {
  const { language } = useLanguageContext();
  
  const t = (key: string) => {
    // Handle nested keys like 'hero.title'
    const keys = key.split('.');
    let translation: any = translations[language];
    
    for (const k of keys) {
      if (translation && translation[k]) {
        translation = translation[k];
      } else {
        return key; // Fallback to key if translation not found
      }
    }
    
    return translation;
  };
  
  return { t, language };
};