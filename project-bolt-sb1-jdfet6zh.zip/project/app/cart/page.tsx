'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useTranslation } from '@/hooks/use-translation';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  ArrowRight,
  Trash2,
  CreditCard,
  AlertCircle
} from 'lucide-react';

// Mock cart data
const initialCart = [
  {
    id: 'wrist1',
    song: {
      title: 'Blinding Lights',
      artist: 'The Weeknd',
      albumArt: 'https://i.scdn.co/image/ab67616d0000b273c5649add07ed3720be9d5526',
    },
    printStyle: 'spotifyCode',
    material: 'Silicone',
    color: 'Black',
    price: 14.99,
    quantity: 1,
  }
];

export default function CartPage() {
  const { t } = useTranslation();
  const [cart, setCart] = useState(initialCart);
  
  const handleQuantityChange = (id, newQuantity) => {
    if (newQuantity < 1) return;
    
    setCart(prevCart => 
      prevCart.map(item => 
        item.id === id ? { ...item, quantity: newQuantity } : item
      )
    );
  };
  
  const handleRemoveItem = (id) => {
    setCart(prevCart => prevCart.filter(item => item.id !== id));
  };
  
  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = cart.length > 0 ? 4.99 : 0;
  const tax = subtotal * 0.1; // 10% tax
  const total = subtotal + shipping + tax;

  return (
    <div className="container mx-auto px-4 py-32">
      <h1 className="text-3xl md:text-4xl font-bold mb-8">
        {t('checkout.title')}
      </h1>
      
      {cart.length === 0 ? (
        <Card className="text-center py-16 bg-zinc-900 border-zinc-800">
          <CardContent>
            <div className="flex flex-col items-center">
              <AlertCircle className="h-16 w-16 text-muted-foreground mb-4" />
              <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
              <p className="text-muted-foreground mb-6">
                Looks like you haven't added any wristbands to your cart yet.
              </p>
              <Link href="/customize">
                <Button className="bg-[#1DB954] hover:bg-[#1ed760] text-black font-bold">
                  Start Designing
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-8">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Shopping Cart</CardTitle>
                <CardDescription>
                  {cart.length} {cart.length === 1 ? 'item' : 'items'} in your cart
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {cart.map(item => (
                  <div key={item.id} className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4 py-4 border-b border-zinc-800">
                    <div className="w-24 h-24 bg-zinc-800 rounded-md flex-shrink-0 flex items-center justify-center">
                      <img 
                        src={item.song.albumArt} 
                        alt={`${item.song.title} album art`} 
                        className="w-20 h-20 rounded-sm"
                      />
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="font-medium">{item.song.title}</h3>
                      <p className="text-sm text-gray-400">{item.song.artist}</p>
                      <div className="flex flex-wrap gap-2 mt-2">
                        <span className="bg-zinc-800 px-2 py-1 rounded text-xs">
                          {item.printStyle === 'spotifyCode' ? 'Spotify Code' : 'Text Only'}
                        </span>
                        <span className="bg-zinc-800 px-2 py-1 rounded text-xs">
                          {item.material}
                        </span>
                        <span className="bg-zinc-800 px-2 py-1 rounded text-xs">
                          {item.color}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4 sm:space-x-8">
                      <div className="flex items-center space-x-2">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                        >
                          -
                        </Button>
                        <span className="w-8 text-center">{item.quantity}</span>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                        >
                          +
                        </Button>
                      </div>
                      
                      <div className="text-right">
                        <div className="font-medium">${(item.price * item.quantity).toFixed(2)}</div>
                        <div className="text-sm text-gray-400">${item.price.toFixed(2)} each</div>
                      </div>
                      
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-gray-400 hover:text-red-500"
                        onClick={() => handleRemoveItem(item.id)}
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
              <CardFooter>
                <Link href="/customize" className="w-full">
                  <Button variant="outline" className="w-full">
                    Continue Shopping
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
          
          {/* Order Summary */}
          <div className="lg:col-span-4">
            <Card className="bg-zinc-900 border-zinc-800 sticky top-24">
              <CardHeader>
                <CardTitle>{t('checkout.orderSummary')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">{t('checkout.subtotal')}</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">{t('checkout.shipping')}</span>
                  <span>${shipping.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">{t('checkout.tax')}</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
                
                <Separator className="my-2" />
                
                <div className="flex justify-between font-semibold text-lg">
                  <span>{t('checkout.total')}</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                
                <div className="pt-4">
                  <h4 className="text-sm font-medium mb-2">{t('checkout.paymentMethods')}</h4>
                  <div className="flex flex-wrap gap-2">
                    <div className="bg-zinc-800 p-2 rounded">
                      <CreditCard className="h-6 w-6" />
                    </div>
                    <div className="bg-zinc-800 p-2 rounded">
                      <img src="https://static-assets.bamgrid.com/product/disneyplus/images/logos/paypal-logo.svg" alt="PayPal" className="h-6" />
                    </div>
                    <div className="bg-zinc-800 p-2 rounded">
                      <img src="https://seeklogo.com/images/A/apple-pay-logo-CFD6ECB506-seeklogo.com.png" alt="Apple Pay" className="h-6" />
                    </div>
                    <div className="bg-zinc-800 p-2 rounded">
                      <span className="text-xs font-semibold">Ziraat</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/checkout" className="w-full">
                  <Button className="w-full bg-[#1DB954] hover:bg-[#1ed760] text-black font-bold">
                    {t('checkout.placeOrder')}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}