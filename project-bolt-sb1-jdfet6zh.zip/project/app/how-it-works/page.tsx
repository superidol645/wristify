'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useTranslation } from '@/hooks/use-translation';
import { Button } from '@/components/ui/button';
import { 
  ArrowRight, 
  Music, 
  Smartphone, 
  Package, 
  Truck 
} from 'lucide-react';

export default function HowItWorks() {
  const { t } = useTranslation();

  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 px-4 bg-gradient-to-b from-zinc-900 to-black">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            How <span className="text-[#1DB954]">Wristify</span> Works
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-12">
            From song selection to wearing your music, here's how to create your custom Spotify wristband.
          </p>
        </div>
      </section>

      {/* Step 1 */}
      <section className="py-20 bg-zinc-900">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="md:w-1/2">
              <div className="bg-[#1DB954]/10 inline-flex rounded-full px-4 py-1 text-[#1DB954] text-sm font-semibold mb-6">
                Step 1
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Choose Your Favorite Song
              </h2>
              <p className="text-lg text-gray-300 mb-6">
                Connect your Spotify account to browse your playlists or paste a Spotify song URL directly. We'll use this to create your unique wristband.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Connect your Spotify account</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Browse your favorite songs or playlists</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Or paste any Spotify song URL</span>
                </li>
              </ul>
            </div>
            <div className="md:w-1/2">
              <div className="rounded-xl overflow-hidden shadow-2xl">
                <Image 
                  src="https://images.pexels.com/photos/7149165/pexels-photo-7149165.jpeg" 
                  alt="Choosing a song on Spotify"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Step 2 */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row-reverse items-center justify-between gap-12">
            <div className="md:w-1/2">
              <div className="bg-[#1DB954]/10 inline-flex rounded-full px-4 py-1 text-[#1DB954] text-sm font-semibold mb-6">
                Step 2
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Customize Your Design
              </h2>
              <p className="text-lg text-gray-300 mb-6">
                Choose between a scannable Spotify code or text with song and artist name. Our real-time 3D preview shows exactly how your wristband will look.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Select Spotify code or text-only design</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Choose between available materials and colors</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>See your design in real-time 3D preview</span>
                </li>
              </ul>
            </div>
            <div className="md:w-1/2">
              <div className="rounded-xl overflow-hidden shadow-2xl">
                <Image 
                  src="https://images.pexels.com/photos/7148429/pexels-photo-7148429.jpeg" 
                  alt="Customizing design"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Step 3 */}
      <section className="py-20 bg-zinc-900">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-12">
            <div className="md:w-1/2">
              <div className="bg-[#1DB954]/10 inline-flex rounded-full px-4 py-1 text-[#1DB954] text-sm font-semibold mb-6">
                Step 3
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Place Your Order
              </h2>
              <p className="text-lg text-gray-300 mb-6">
                Complete your purchase with our secure checkout process. We support multiple payment methods including credit cards, PayPal, Apple Pay, Google Pay, and Ziraat Bankası.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Review your design and add to cart</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Enter shipping and payment information</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Choose from multiple secure payment options</span>
                </li>
              </ul>
            </div>
            <div className="md:w-1/2">
              <div className="rounded-xl overflow-hidden shadow-2xl">
                <Image 
                  src="https://images.pexels.com/photos/6863515/pexels-photo-6863515.jpeg" 
                  alt="Checkout process"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Step 4 */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row-reverse items-center justify-between gap-12">
            <div className="md:w-1/2">
              <div className="bg-[#1DB954]/10 inline-flex rounded-full px-4 py-1 text-[#1DB954] text-sm font-semibold mb-6">
                Step 4
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Receive & Enjoy
              </h2>
              <p className="text-lg text-gray-300 mb-6">
                We'll craft your custom wristband and ship it directly to you. Then simply scan with the Spotify app to instantly play your song!
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Receive tracking information by email</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Wear your custom Wristify band</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-[#1DB954]/20 rounded-full p-1 mr-3 mt-0.5">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                      <path d="M13.3334 4L6.00008 11.3333L2.66675 8" stroke="#1DB954" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <span>Scan with Spotify app to play your song instantly</span>
                </li>
              </ul>
            </div>
            <div className="md:w-1/2">
              <div className="rounded-xl overflow-hidden shadow-2xl">
                <Image 
                  src="https://images.pexels.com/photos/7241628/pexels-photo-7241628.jpeg" 
                  alt="Wearing wristband"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#1DB954]">
        <div className="container mx-auto px-4 text-center text-black">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Ready to create your own Wristify band?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Start designing your custom Spotify wristband in minutes.
          </p>
          <Link href="/customize">
            <Button 
              size="lg" 
              className="bg-black text-white hover:bg-zinc-800 font-bold px-8 py-6 text-lg"
            >
              Start Designing
              <ArrowRight className="ml-2" />
            </Button>
          </Link>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-20 bg-zinc-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center">
            Frequently Asked Questions
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="space-y-2">
              <h3 className="text-xl font-medium">How does the Spotify code work?</h3>
              <p className="text-gray-400">
                The Spotify code on your wristband works just like a QR code. Open the Spotify app, tap the search icon, then tap the camera icon to scan your wristband and instantly play your song.
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-medium">What if I don't have a Spotify account?</h3>
              <p className="text-gray-400">
                You can still design and order a wristband without a Spotify account by pasting song URLs, but scanning the code will require the free Spotify app.
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-medium">How long does shipping take?</h3>
              <p className="text-gray-400">
                Standard shipping typically takes 5-7 business days. Express shipping options are available at checkout for faster delivery.
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-medium">Can I change my song after ordering?</h3>
              <p className="text-gray-400">
                Unfortunately, once your wristband is in production, we cannot change the song. Please make sure you're happy with your selection before completing your order.
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-medium">Are the wristbands waterproof?</h3>
              <p className="text-gray-400">
                Yes! Our silicone wristbands are water-resistant and designed to withstand everyday activities, including handwashing and light exposure to water.
              </p>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-xl font-medium">What payment methods do you accept?</h3>
              <p className="text-gray-400">
                We accept all major credit cards, PayPal, Apple Pay, Google Pay, and Ziraat Bankası for our Turkish customers.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}