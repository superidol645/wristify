'use client';

import { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  Download, 
  Package,
  DollarSign,
  Users,
  TrendingUp,
  FileText
} from 'lucide-react';

// Mock data for orders
const mockOrders = [
  {
    id: 'ORD12345',
    date: '2025-04-15',
    customer: 'Emma Wilson',
    email: 'emma@example.com',
    total: 14.99,
    status: 'processing',
    paymentStatus: 'paid',
    items: [
      { song: 'Blinding Lights - The Weeknd', style: 'Spotify Code', color: 'Black' }
    ]
  },
  {
    id: 'ORD12346',
    date: '2025-04-14',
    customer: 'John Smith',
    email: 'john@example.com',
    total: 29.98,
    status: 'shipped',
    paymentStatus: 'paid',
    items: [
      { song: 'Shape of You - Ed Sheeran', style: 'Text Only', color: 'Black' },
      { song: 'Bad Guy - Billie Eilish', style: 'Spotify Code', color: 'Black' }
    ]
  },
  {
    id: 'ORD12347',
    date: '2025-04-13',
    customer: 'Ahmet Yılmaz',
    email: 'ahmet@example.com',
    total: 14.99,
    status: 'delivered',
    paymentStatus: 'paid',
    items: [
      { song: 'Dance Monkey - Tones and I', style: 'Spotify Code', color: 'Black' }
    ]
  },
  {
    id: 'ORD12348',
    date: '2025-04-12',
    customer: 'María García',
    email: 'maria@example.com',
    total: 14.99,
    status: 'processing',
    paymentStatus: 'pending',
    items: [
      { song: 'Levitating - Dua Lipa', style: 'Spotify Code', color: 'Black' }
    ]
  },
  {
    id: 'ORD12349',
    date: '2025-04-11',
    customer: 'Mohammed Al-Farsi',
    email: 'mohammed@example.com',
    total: 29.98,
    status: 'cancelled',
    paymentStatus: 'refunded',
    items: [
      { song: 'Blinding Lights - The Weeknd', style: 'Text Only', color: 'Black' },
      { song: 'Shape of You - Ed Sheeran', style: 'Spotify Code', color: 'Black' }
    ]
  }
];

export default function AdminDashboard() {
  const [orders, setOrders] = useState(mockOrders);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // Filter orders based on search and status filter
  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.email.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
  
  const updateOrderStatus = (orderId, newStatus) => {
    setOrders(prev => 
      prev.map(order => 
        order.id === orderId ? { ...order, status: newStatus } : order
      )
    );
  };
  
  // Calculate summary stats
  const totalSales = orders.reduce((sum, order) => sum + order.total, 0);
  const processingOrders = orders.filter(order => order.status === 'processing').length;
  const shippedOrders = orders.filter(order => order.status === 'shipped').length;
  const completedOrders = orders.filter(order => order.status === 'delivered').length;

  return (
    <div className="container mx-auto px-4 py-32">
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalSales.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              +12.5% from last month
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orders.length}</div>
            <p className="text-xs text-muted-foreground">
              +2 new customers today
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Orders</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{processingOrders}</div>
            <p className="text-xs text-muted-foreground">
              {shippedOrders} orders shipped
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-zinc-900 border-zinc-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Completed Orders</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedOrders}</div>
            <p className="text-xs text-muted-foreground">
              Lifetime completed orders
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Order Management */}
      <Tabs defaultValue="orders" className="mb-8">
        <TabsList>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="orders">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle>Order Management</CardTitle>
              <CardDescription>
                Manage your customer orders and update their status.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    type="search"
                    placeholder="Search orders..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="shipped">Shipped</SelectItem>
                    <SelectItem value="delivered">Delivered</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="flex items-center gap-2">
                  <Download className="h-4 w-4" />
                  <span>Export CSV</span>
                </Button>
              </div>
              
              <div className="rounded-md border border-zinc-800">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Payment</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredOrders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.id}</TableCell>
                        <TableCell>{order.date}</TableCell>
                        <TableCell>
                          <div>{order.customer}</div>
                          <div className="text-xs text-gray-400">{order.email}</div>
                        </TableCell>
                        <TableCell>{order.items.length}</TableCell>
                        <TableCell>${order.total.toFixed(2)}</TableCell>
                        <TableCell>
                          <Badge 
                            className={`
                              ${order.status === 'processing' ? 'bg-blue-500/20 text-blue-500 hover:bg-blue-500/30' : ''}
                              ${order.status === 'shipped' ? 'bg-orange-500/20 text-orange-500 hover:bg-orange-500/30' : ''}
                              ${order.status === 'delivered' ? 'bg-green-500/20 text-green-500 hover:bg-green-500/30' : ''}
                              ${order.status === 'cancelled' ? 'bg-red-500/20 text-red-500 hover:bg-red-500/30' : ''}
                            `}
                          >
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant="outline" 
                            className={`
                              ${order.paymentStatus === 'paid' ? 'border-green-500 text-green-500' : ''}
                              ${order.paymentStatus === 'pending' ? 'border-yellow-500 text-yellow-500' : ''}
                              ${order.paymentStatus === 'refunded' ? 'border-red-500 text-red-500' : ''}
                            `}
                          >
                            {order.paymentStatus}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Select 
                            value={order.status} 
                            onValueChange={(value) => updateOrderStatus(order.id, value)}
                          >
                            <SelectTrigger className="h-8 w-[130px]">
                              <SelectValue placeholder="Change status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="processing">Processing</SelectItem>
                              <SelectItem value="shipped">Shipped</SelectItem>
                              <SelectItem value="delivered">Delivered</SelectItem>
                              <SelectItem value="cancelled">Cancelled</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="customers">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle>Customer Management</CardTitle>
              <CardDescription>
                View and manage customer information.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center p-12">
                <div className="text-center">
                  <FileText className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-4 text-lg font-medium">Customer Management</h3>
                  <p className="mt-2 text-sm text-gray-400 max-w-sm">
                    This feature will be available in the next update.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="products">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle>Product Management</CardTitle>
              <CardDescription>
                Manage product inventory and availability.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center p-12">
                <div className="text-center">
                  <Package className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-4 text-lg font-medium">Product Management</h3>
                  <p className="mt-2 text-sm text-gray-400 max-w-sm">
                    This feature will be available in the next update.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle>Admin Settings</CardTitle>
              <CardDescription>
                Configure dashboard and notification settings.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center p-12">
                <div className="text-center">
                  <FileText className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-4 text-lg font-medium">Admin Settings</h3>
                  <p className="mt-2 text-sm text-gray-400 max-w-sm">
                    This feature will be available in the next update.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}