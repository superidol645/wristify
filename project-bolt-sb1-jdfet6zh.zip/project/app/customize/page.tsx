'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useTranslation } from '@/hooks/use-translation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import {
  RadioGroup,
  RadioGroupItem
} from '@/components/ui/radio-group';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { 
  Search, 
  Music, 
  Plus, 
  ShoppingCart, 
  Heart 
} from 'lucide-react';
import WristbandPreview from '@/components/wristband-model';

// Mock song data
const mockSongs = [
  { id: '1', title: 'Blinding Lights', artist: 'The Weeknd', albumArt: 'https://i.scdn.co/image/ab67616d0000b273c5649add07ed3720be9d5526' },
  { id: '2', title: 'Shape of You', artist: 'Ed Sheeran', albumArt: 'https://i.scdn.co/image/ab67616d0000b273ba5db46f4b838ef6027e6f96' },
  { id: '3', title: 'Dance Monkey', artist: 'Tones and I', albumArt: 'https://i.scdn.co/image/ab67616d0000b2739f5cce8304c42d3a5463fd23' },
  { id: '4', title: 'Levitating', artist: 'Dua Lipa', albumArt: 'https://i.scdn.co/image/ab67616d0000b2734eeeeeeeeeeeeeeeeeeeeee' },
  { id: '5', title: 'Bad Guy', artist: 'Billie Eilish', albumArt: 'https://i.scdn.co/image/ab67616d0000b2737005885df706891a3c182a57' },
];

export default function CustomizePage() {
  const { t } = useTranslation();
  const [songUrl, setSongUrl] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState(mockSongs);
  const [selectedSong, setSelectedSong] = useState(null);
  const [printStyle, setPrintStyle] = useState('spotifyCode');
  const [inputTab, setInputTab] = useState('url');
  
  const handleSearch = () => {
    // In a real app, this would call the Spotify API
    // For now, we'll just filter our mock data
    const filtered = mockSongs.filter(
      song => 
        song.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        song.artist.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setSearchResults(filtered);
  };
  
  const handleSelectSong = (song) => {
    setSelectedSong(song);
  };
  
  const handleAddToCart = () => {
    // Add to cart logic would go here
    console.log('Added to cart:', { selectedSong, printStyle });
    // Show confirmation message or redirect
  };

  return (
    <div className="container mx-auto px-4 py-32">
      <h1 className="text-3xl md:text-4xl font-bold mb-12 text-center">
        {t('customizer.title')}
      </h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* 3D Preview */}
        <div className="lg:col-span-5 order-2 lg:order-1">
          <Card className="h-full bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle>{t('customizer.preview')}</CardTitle>
              <CardDescription>
                {selectedSong ? 
                  `${selectedSong.title} - ${selectedSong.artist}` : 
                  'Select a song to preview your wristband'}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="h-[400px] w-full">
                <WristbandPreview />
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Customization Options */}
        <div className="lg:col-span-7 order-1 lg:order-2">
          <Card className="bg-zinc-900 border-zinc-800">
            <CardHeader>
              <CardTitle>{t('customizer.title')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* Song Selection */}
              <div>
                <h3 className="text-lg font-medium mb-4">Select Your Song</h3>
                
                <Tabs value={inputTab} onValueChange={setInputTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-4">
                    <TabsTrigger value="url">{t('customizer.songInput')}</TabsTrigger>
                    <TabsTrigger value="search">{t('customizer.searchSongs')}</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="url" className="space-y-4">
                    <Input 
                      placeholder="https://open.spotify.com/track/..." 
                      value={songUrl} 
                      onChange={(e) => setSongUrl(e.target.value)}
                    />
                    <Button 
                      onClick={() => console.log('Load from URL:', songUrl)}
                      className="w-full"
                    >
                      <Music className="mr-2 h-4 w-4" />
                      Load Song
                    </Button>
                  </TabsContent>
                  
                  <TabsContent value="search" className="space-y-4">
                    <div className="flex gap-2">
                      <Input 
                        placeholder={t('customizer.songPlaceholder')}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                      />
                      <Button onClick={handleSearch}>
                        <Search className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="space-y-2 max-h-[300px] overflow-y-auto">
                      {searchResults.map((song) => (
                        <div 
                          key={song.id}
                          className={`flex items-center gap-3 p-2 rounded-md cursor-pointer hover:bg-zinc-800 transition-colors ${
                            selectedSong?.id === song.id ? 'bg-zinc-800 border-l-2 border-[#1DB954]' : ''
                          }`}
                          onClick={() => handleSelectSong(song)}
                        >
                          <img 
                            src={song.albumArt} 
                            alt={`${song.title} album art`}
                            className="w-12 h-12 rounded"
                          />
                          <div>
                            <div className="font-medium">{song.title}</div>
                            <div className="text-sm text-gray-400">{song.artist}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
              
              <Separator />
              
              {/* Selected Song */}
              {selectedSong && (
                <div>
                  <h3 className="text-lg font-medium mb-4">{t('customizer.selectedSong')}</h3>
                  <div className="flex items-center gap-4 p-4 bg-zinc-800 rounded-md">
                    <img 
                      src={selectedSong.albumArt} 
                      alt={`${selectedSong.title} album art`}
                      className="w-16 h-16 rounded"
                    />
                    <div>
                      <div className="font-medium text-lg">{selectedSong.title}</div>
                      <div className="text-gray-400">{selectedSong.artist}</div>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Print Style */}
              <div>
                <h3 className="text-lg font-medium mb-4">{t('customizer.printStyle')}</h3>
                <RadioGroup 
                  value={printStyle} 
                  onValueChange={setPrintStyle}
                  className="flex gap-4"
                >
                  <div className="flex items-center space-x-2 bg-zinc-800 p-4 rounded-md flex-1 cursor-pointer hover:bg-zinc-700 transition-colors">
                    <RadioGroupItem value="spotifyCode" id="spotifyCode" />
                    <Label htmlFor="spotifyCode" className="cursor-pointer">
                      <div className="font-medium">{t('customizer.spotifyCode')}</div>
                      <div className="text-sm text-gray-400">Scannable with Spotify app</div>
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2 bg-zinc-800 p-4 rounded-md flex-1 cursor-pointer hover:bg-zinc-700 transition-colors">
                    <RadioGroupItem value="textOnly" id="textOnly" />
                    <Label htmlFor="textOnly" className="cursor-pointer">
                      <div className="font-medium">{t('customizer.textOnly')}</div>
                      <div className="text-sm text-gray-400">Song name and artist</div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              
              {/* Material */}
              <div>
                <h3 className="text-lg font-medium mb-4">{t('materials.title')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-zinc-800 p-4 rounded-md border-2 border-[#1DB954]">
                    <div className="font-medium">Silicone</div>
                    <div className="text-sm text-gray-400">Soft and durable</div>
                  </div>
                  
                  <div className="bg-zinc-800/50 p-4 rounded-md opacity-50 cursor-not-allowed">
                    <div className="font-medium">Fabric</div>
                    <div className="text-sm text-red-400">{t('materials.outOfStock')}</div>
                  </div>
                </div>
              </div>
              
              {/* Color */}
              <div>
                <h3 className="text-lg font-medium mb-4">{t('colors.title')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-zinc-800 p-4 rounded-md border-2 border-[#1DB954] flex items-center">
                    <div className="w-6 h-6 rounded-full bg-black mr-3 shadow-sm"></div>
                    <div className="font-medium">{t('colors.black')}</div>
                  </div>
                  
                  <div className="bg-zinc-800/50 p-4 rounded-md opacity-50 cursor-not-allowed flex items-center">
                    <div className="w-6 h-6 rounded-full bg-white mr-3 shadow-sm"></div>
                    <div className="font-medium">{t('colors.white')}</div>
                    <div className="text-sm text-red-400 ml-auto">{t('materials.outOfStock')}</div>
                  </div>
                </div>
              </div>
            </CardContent>
            
            <CardFooter className="flex gap-4">
              <Button 
                onClick={handleAddToCart} 
                disabled={!selectedSong}
                className="flex-1 bg-[#1DB954] hover:bg-[#1ed760] text-black font-bold"
              >
                <ShoppingCart className="mr-2 h-4 w-4" />
                {t('customizer.addToCart')}
              </Button>
              
              <Button variant="outline" className="flex-1" disabled={!selectedSong}>
                <Heart className="mr-2 h-4 w-4" />
                {t('customizer.saveDesign')}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}