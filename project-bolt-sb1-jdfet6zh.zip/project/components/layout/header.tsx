'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTranslation } from '@/hooks/use-translation';
import { Button } from '@/components/ui/button';
import { ModeToggle } from '@/components/mode-toggle';
import { LanguageSelector } from '@/components/language-selector';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  ShoppingCart, 
  User, 
  LogOut, 
  Menu, 
  X, 
  Heart, 
  Clock, 
  Settings 
} from 'lucide-react';

const Header = () => {
  const { t } = useTranslation();
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSpotifyLogin = () => {
    console.log('Spotify login clicked');
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-black bg-opacity-90 backdrop-blur-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link href="/" className="flex items-center space-x-2">
          <svg viewBox="0 0 24 24" className="h-8 w-8 text-[#1DB954]" fill="currentColor">
            <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
          </svg>
          <span className="text-xl font-bold">Wristify</span>
        </Link>
        
        <div className="hidden md:flex items-center space-x-6">
          <nav className="flex items-center space-x-6">
            <Link 
              href="/customize" 
              className={`hover:text-[#1DB954] transition-colors ${
                pathname === '/customize' ? 'text-[#1DB954]' : 'text-white'
              }`}
            >
              {t('customize')}
            </Link>
            <Link 
              href="/gallery" 
              className={`hover:text-[#1DB954] transition-colors ${
                pathname === '/gallery' ? 'text-[#1DB954]' : 'text-white'
              }`}
            >
              {t('gallery')}
            </Link>
            <Link 
              href="/how-it-works" 
              className={`hover:text-[#1DB954] transition-colors ${
                pathname === '/how-it-works' ? 'text-[#1DB954]' : 'text-white'
              }`}
            >
              {t('howItWorks')}
            </Link>
          </nav>
          
          <div className="flex items-center space-x-3">
            <LanguageSelector />
            <ModeToggle />
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 bg-[#1DB954] text-black text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  0
                </span>
              </Button>
            </Link>
            
            {isLoggedIn ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Avatar className="cursor-pointer">
                    <AvatarImage src="https://i.pravatar.cc/100" />
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>{t('myAccount')}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    <span>{t('profile')}</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Heart className="mr-2 h-4 w-4" />
                    <span>{t('savedDesigns')}</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Clock className="mr-2 h-4 w-4" />
                    <span>{t('orderHistory')}</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>{t('settings')}</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>{t('logout')}</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button 
                onClick={handleSpotifyLogin} 
                className="bg-[#1DB954] hover:bg-[#1ed760] text-black font-bold"
              >
                {t('loginWithSpotify')}
              </Button>
            )}
          </div>
        </div>
        
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden" 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-black bg-opacity-95 absolute top-16 left-0 w-full py-4 px-6">
          <nav className="flex flex-col space-y-4">
            <Link 
              href="/customize" 
              className={`hover:text-[#1DB954] transition-colors ${
                pathname === '/customize' ? 'text-[#1DB954]' : 'text-white'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('customize')}
            </Link>
            <Link 
              href="/gallery" 
              className={`hover:text-[#1DB954] transition-colors ${
                pathname === '/gallery' ? 'text-[#1DB954]' : 'text-white'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('gallery')}
            </Link>
            <Link 
              href="/how-it-works" 
              className={`hover:text-[#1DB954] transition-colors ${
                pathname === '/how-it-works' ? 'text-[#1DB954]' : 'text-white'
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              {t('howItWorks')}
            </Link>
            <div className="pt-2 flex items-center space-x-3">
              <LanguageSelector />
              <ModeToggle />
              <Link href="/cart" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 bg-[#1DB954] text-black text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    0
                  </span>
                </Button>
              </Link>
            </div>
            {!isLoggedIn && (
              <Button 
                onClick={() => {
                  handleSpotifyLogin();
                  setMobileMenuOpen(false);
                }}
                className="mt-2 bg-[#1DB954] hover:bg-[#1ed760] text-black font-bold w-full"
              >
                {t('loginWithSpotify')}
              </Button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;