'use client';

import Link from 'next/link';
import { useTranslation } from '@/hooks/use-translation';
import { Facebook, Twitter, Instagram, Music } from 'lucide-react';

const Footer = () => {
  const { t } = useTranslation();
  
  return (
    <footer className="bg-zinc-900 text-zinc-400 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <Music className="h-6 w-6 text-[#1DB954]" />
              <span className="text-lg font-bold text-white">Wristify</span>
            </Link>
            <p className="text-sm mb-4">
              {t('footerTagline')}
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-[#1DB954] transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-[#1DB954] transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="hover:text-[#1DB954] transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">{t('products')}</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/customize" className="hover:text-[#1DB954] transition-colors">
                  {t('customizeWristband')}
                </Link>
              </li>
              <li>
                <Link href="/gallery" className="hover:text-[#1DB954] transition-colors">
                  {t('designGallery')}
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#1DB954] transition-colors">
                  {t('giftCards')}
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">{t('company')}</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="hover:text-[#1DB954] transition-colors">
                  {t('aboutUs')}
                </Link>
              </li>
              <li>
                <Link href="/how-it-works" className="hover:text-[#1DB954] transition-colors">
                  {t('howItWorks')}
                </Link>
              </li>
              <li>
                <Link href="/faq" className="hover:text-[#1DB954] transition-colors">
                  {t('faq')}
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-[#1DB954] transition-colors">
                  {t('contactUs')}
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-medium mb-4">{t('legal')}</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/terms" className="hover:text-[#1DB954] transition-colors">
                  {t('termsOfService')}
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-[#1DB954] transition-colors">
                  {t('privacyPolicy')}
                </Link>
              </li>
              <li>
                <Link href="/shipping" className="hover:text-[#1DB954] transition-colors">
                  {t('shippingPolicy')}
                </Link>
              </li>
              <li>
                <Link href="/refunds" className="hover:text-[#1DB954] transition-colors">
                  {t('refundPolicy')}
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-zinc-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm">
            &copy; {new Date().getFullYear()} Wristify. {t('allRightsReserved')}
          </p>
          <div className="flex items-center space-x-4 mt-4 md:mt-0">
            <img src="https://static-assets.bamgrid.com/product/disneyplus/images/logos/visa-card-logo.svg" alt="Visa" className="h-6" />
            <img src="https://static-assets.bamgrid.com/product/disneyplus/images/logos/mastercard-logo.svg" alt="Mastercard" className="h-6" />
            <img src="https://static-assets.bamgrid.com/product/disneyplus/images/logos/paypal-logo.svg" alt="PayPal" className="h-6" />
            <img src="https://seeklogo.com/images/A/apple-pay-logo-CFD6ECB506-seeklogo.com.png" alt="Apple Pay" className="h-6" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;