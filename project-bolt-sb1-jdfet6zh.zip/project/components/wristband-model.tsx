'use client';

import Image from 'next/image';

export default function WristbandPreview({ songTitle = "Someone Like You" }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-b from-zinc-900 to-black p-8 rounded-lg">
      <div className="relative w-full max-w-md aspect-[4/3]">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-full max-w-[300px] h-[80px] bg-white rounded-lg shadow-lg flex items-center px-4 space-x-2">
            <div className="w-6 h-6">
              <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="black"/>
                <path d="M16.5 12C16.5 14.4853 14.4853 16.5 12 16.5C9.51472 16.5 7.5 14.4853 7.5 12C7.5 9.51472 9.51472 7.5 12 7.5C14.4853 7.5 16.5 9.51472 16.5 12Z" fill="white"/>
              </svg>
            </div>
            <div className="flex-1">
              <div className="h-4 bg-black rounded-full w-[80%]" />
            </div>
            <div className="text-sm font-medium text-black">{songTitle}</div>
          </div>
        </div>
      </div>
    </div>
  );
}